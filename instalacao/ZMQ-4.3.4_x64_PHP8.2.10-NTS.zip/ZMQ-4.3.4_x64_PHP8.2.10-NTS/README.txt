ZMQ 4.3.4_x64 to PHP 8.2.10 - NTS

place libzmq-v142-mt-4_3_4.dll in <path_to_php>/
place php_zmq.dll in <path_to_php>/ext

(IT TOOK ME HOURS TO DO THAT hahaha)